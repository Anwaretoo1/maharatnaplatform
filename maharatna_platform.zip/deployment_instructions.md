# تعليمات نشر منصة مهاراتنا على Netlify

هذا الملف يحتوي على تعليمات مفصلة حول كيفية نشر منصة مهاراتنا على Netlify وربطها بالدومين maharat-syria.com.

## الخطوة 1: إنشاء مستودع GitHub

1. قم بتسجيل الدخول إلى حسابك على GitHub
2. انقر على زر "+" في الزاوية العلوية اليمنى واختر "New repository"
3. أدخل اسم المستودع (مثلاً: "maharatna-platform")
4. اختر "Private" إذا كنت ترغب في إبقاء المستودع خاصاً
5. انقر على "Create repository"
6. اتبع التعليمات لرفع الكود الموجود في المجلد المضغوط إلى المستودع:

```bash
git remote add origin https://github.com/yourusername/maharatna-platform.git
git branch -M main
git push -u origin main
```

## الخطوة 2: نشر المشروع على Netlify

1. قم بتسجيل الدخول إلى حسابك على Netlify (أو قم بإنشاء حساب جديد)
2. انقر على زر "Add new site" واختر "Import an existing project"
3. اختر "Deploy with GitHub"
4. اتبع التعليمات للسماح لـ Netlify بالوصول إلى حسابك على GitHub
5. اختر المستودع الذي أنشأته للمشروع
6. في إعدادات النشر، تأكد من:
   - Build command: `npm run build`
   - Publish directory: `.next`
7. انقر على "Deploy site"

## الخطوة 3: تكوين المتغيرات البيئية

بعد نشر الموقع، ستحتاج إلى إضافة متغيرات البيئة الخاصة بـ Supabase:

1. في لوحة تحكم Netlify، انتقل إلى "Site settings" > "Environment variables"
2. أضف المتغيرات التالية:
   - NEXT_PUBLIC_SUPABASE_URL: قيمة URL الخاص بمشروع Supabase
   - NEXT_PUBLIC_SUPABASE_ANON_KEY: المفتاح العام لمشروع Supabase

## الخطوة 4: ربط الدومين المخصص

لربط الدومين maharat-syria.com بموقعك على Netlify:

1. في لوحة تحكم Netlify، انتقل إلى "Site settings" > "Domain management"
2. انقر على "Add custom domain"
3. أدخل "maharat-syria.com" واتبع التعليمات
4. ستحتاج إلى تحديث إعدادات DNS للدومين لتوجيهه إلى Netlify:
   - أضف سجل CNAME يشير إلى عنوان Netlify الخاص بموقعك
   - أو استخدم خوادم DNS الخاصة بـ Netlify (موصى به)

## الخطوة 5: التحقق من النشر

بعد اكتمال عملية النشر، يمكنك الوصول إلى موقعك من خلال:
1. عنوان URL المؤقت الذي توفره Netlify (مثل https://your-site-name.netlify.app)
2. الدومين المخصص maharat-syria.com (بعد اكتمال إعدادات DNS)

## ملاحظات هامة

- تأكد من أن إعدادات DNS قد تم تحديثها بشكل صحيح وانتظر فترة انتشار DNS (قد تستغرق حتى 48 ساعة)
- يمكنك تمكين HTTPS تلقائياً من خلال Netlify لتأمين موقعك
- للتحديثات المستقبلية، ما عليك سوى دفع التغييرات إلى مستودع GitHub وسيقوم Netlify تلقائياً بإعادة بناء ونشر موقعك

إذا واجهت أي مشاكل أثناء عملية النشر، يمكنك الرجوع إلى [وثائق Netlify](https://docs.netlify.com/) للحصول على مزيد من المعلومات.
