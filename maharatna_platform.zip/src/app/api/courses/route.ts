import { NextRequest, NextResponse } from 'next/server';
import { getAllCourses, getCourseById, createCourse } from '@/lib/courses';

export async function GET(request: NextRequest) {
  try {
    // Get query parameters for filtering
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    const category = searchParams.get('category');
    const creatorId = searchParams.get('creatorId');
    const isFreeParam = searchParams.get('isFree');
    
    if (id) {
      // Get specific course by ID
      const course = await getCourseById(id);
      
      if (!course) {
        return NextResponse.json(
          { error: 'الدورة غير موجودة' },
          { status: 404 }
        );
      }
      
      return NextResponse.json({ course });
    }
    
    // Get all courses with optional filters
    const filters: {
      category?: string;
      creatorId?: string;
      isFree?: boolean;
    } = {};
    
    if (category) filters.category = category;
    if (creatorId) filters.creatorId = creatorId;
    if (isFreeParam !== null) filters.isFree = isFreeParam === 'true';
    
    const courses = await getAllCourses(filters);
    return NextResponse.json({ courses });
  } catch (error) {
    console.error('Error in courses GET route:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء جلب بيانات الدورات' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();
    
    // Validate required fields
    if (!data.title || !data.description || !data.category || !data.creatorId || !data.content) {
      return NextResponse.json(
        { error: 'العنوان والوصف والتصنيف ومعرف المنشئ والمحتوى مطلوبة' },
        { status: 400 }
      );
    }
    
    // Create new course
    const newCourse = await createCourse({
      title: data.title,
      description: data.description,
      category: data.category,
      creatorId: data.creatorId,
      thumbnailUrl: data.thumbnailUrl || '',
      content: data.content,
      isFree: data.isFree || false,
      price: data.price || 0,
    });
    
    return NextResponse.json({ course: newCourse }, { status: 201 });
  } catch (error) {
    console.error('Error in courses POST route:', error);
    return NextResponse.json(
      { error: 'حدث خطأ أثناء إنشاء الدورة' },
      { status: 500 }
    );
  }
}
