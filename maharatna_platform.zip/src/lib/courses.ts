import { supabase } from './supabase';

export interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  creatorId: string;
  thumbnailUrl?: string;
  content: CourseContent[];
  isFree: boolean;
  price?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface CourseContent {
  id: string;
  title: string;
  type: 'video' | 'image' | 'text' | 'file';
  content: string;
  order: number;
}

export async function getAllCourses(filters?: {
  category?: string;
  creatorId?: string;
  isFree?: boolean;
}) {
  let query = supabase.from('courses').select('*');
  
  if (filters?.category) {
    query = query.eq('category', filters.category);
  }
  
  if (filters?.creatorId) {
    query = query.eq('creatorId', filters.creatorId);
  }
  
  if (filters?.isFree !== undefined) {
    query = query.eq('isFree', filters.isFree);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Error fetching courses:', error);
    return [];
  }
  
  return data || [];
}

export async function getCourseById(id: string) {
  const { data, error } = await supabase
    .from('courses')
    .select('*')
    .eq('id', id)
    .single();
  
  if (error) {
    console.error('Error fetching course:', error);
    return null;
  }
  
  return data;
}

export async function createCourse(courseData: Omit<Course, 'id' | 'createdAt' | 'updatedAt'>) {
  const now = new Date().toISOString();
  
  const { data, error } = await supabase
    .from('courses')
    .insert([
      { 
        ...courseData,
        createdAt: now,
        updatedAt: now
      }
    ])
    .select()
    .single();
  
  if (error) {
    console.error('Error creating course:', error);
    throw error;
  }
  
  return data;
}

export async function updateCourse(id: string, courseData: Partial<Course>) {
  const { data, error } = await supabase
    .from('courses')
    .update({
      ...courseData,
      updatedAt: new Date().toISOString()
    })
    .eq('id', id)
    .select()
    .single();
  
  if (error) {
    console.error('Error updating course:', error);
    throw error;
  }
  
  return data;
}

export async function deleteCourse(id: string) {
  const { error } = await supabase
    .from('courses')
    .delete()
    .eq('id', id);
  
  if (error) {
    console.error('Error deleting course:', error);
    throw error;
  }
  
  return true;
}
