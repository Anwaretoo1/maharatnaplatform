import { supabase } from './supabase';

// Define types for donation
interface Donation {
  id: string;
  amount: number;
  donorName: string;
  donorEmail: string;
  recipientType: 'platform' | 'craftsman';
  recipientId?: string; // Only required if donating to a craftsman
  message?: string;
  createdAt: Date;
}

export async function getAllDonations(filters?: {
  recipientType?: 'platform' | 'craftsman';
  recipientId?: string;
}) {
  let query = supabase.from('donations').select('*');
  
  if (filters?.recipientType) {
    query = query.eq('recipientType', filters.recipientType);
  }
  
  if (filters?.recipientId) {
    query = query.eq('recipientId', filters.recipientId);
  }
  
  const { data, error } = await query;
  
  if (error) {
    console.error('Error fetching donations:', error);
    return [];
  }
  
  return data || [];
}

export async function getDonationById(id: string) {
  const { data, error } = await supabase
    .from('donations')
    .select('*')
    .eq('id', id)
    .single();
  
  if (error) {
    console.error('Error fetching donation:', error);
    return null;
  }
  
  return data;
}

export async function createDonation(donationData: Omit<Donation, 'id' | 'createdAt'>) {
  // Validate required fields
  if (!donationData.amount || !donationData.donorName || !donationData.donorEmail || !donationData.recipientType) {
    throw new Error('المبلغ واسم المتبرع والبريد الإلكتروني ونوع المستلم مطلوبة');
  }
  
  // Validate amount
  if (donationData.amount <= 0) {
    throw new Error('يجب أن يكون مبلغ التبرع أكبر من صفر');
  }
  
  // Validate recipient type and ID
  if (donationData.recipientType === 'craftsman' && !donationData.recipientId) {
    throw new Error('معرف الحرفي مطلوب عند التبرع لحرفي');
  }
  
  const { data, error } = await supabase
    .from('donations')
    .insert([
      { 
        ...donationData,
        createdAt: new Date().toISOString()
      }
    ])
    .select()
    .single();
  
  if (error) {
    console.error('Error creating donation:', error);
    throw error;
  }
  
  return data;
}
