import { supabase } from './supabase';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'craftsman' | 'learner' | 'admin';
  bio?: string;
  skills?: string[];
  avatar?: string;
  createdAt: Date;
}

export async function getAllUsers() {
  const { data, error } = await supabase
    .from('users')
    .select('*');
  
  if (error) {
    console.error('Error fetching users:', error);
    return [];
  }
  
  return data || [];
}

export async function getUserById(id: string) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', id)
    .single();
  
  if (error) {
    console.error('Error fetching user:', error);
    return null;
  }
  
  return data;
}

export async function createUser(userData: Omit<User, 'id' | 'createdAt'>) {
  const { data, error } = await supabase
    .from('users')
    .insert([
      { 
        ...userData,
        createdAt: new Date().toISOString()
      }
    ])
    .select()
    .single();
  
  if (error) {
    console.error('Error creating user:', error);
    throw error;
  }
  
  return data;
}

export async function updateUser(id: string, userData: Partial<User>) {
  const { data, error } = await supabase
    .from('users')
    .update(userData)
    .eq('id', id)
    .select()
    .single();
  
  if (error) {
    console.error('Error updating user:', error);
    throw error;
  }
  
  return data;
}

export async function deleteUser(id: string) {
  const { error } = await supabase
    .from('users')
    .delete()
    .eq('id', id);
  
  if (error) {
    console.error('Error deleting user:', error);
    throw error;
  }
  
  return true;
}
